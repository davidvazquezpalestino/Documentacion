﻿namespace BlazingPizza.Models;
public class MyOrdersModel : IMyOrdersModel
{
    readonly IBlazingPizzaWebApiGateway Gateway;

    public MyOrdersModel(IBlazingPizzaWebApiGateway gateway)
    {
        Gateway = gateway;
    }

    public async Task<IReadOnlyCollection<OrderWithStatusDto>> GetOrdersAsync()
    {
        return await Gateway.GetOrdersAsync();
    }
}
