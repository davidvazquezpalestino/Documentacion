﻿namespace BlazingPizza.Models;
public class DesktopSpecialsModel : ISpecialsModel
{
    readonly IGetSpecialsController Controller;

    public DesktopSpecialsModel(IGetSpecialsController controller)
    {
        Controller = controller;
    }

    public Task<IReadOnlyCollection<PizzaSpecial>> GetSpecialsAsync()
    {
        return Controller.GetSpecialsAsync();
    }
}
