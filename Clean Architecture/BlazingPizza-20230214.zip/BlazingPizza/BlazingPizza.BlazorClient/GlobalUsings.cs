﻿global using BlazingPizza.BlazorClient;
global using BlazingPizza.Frontend.IoC;
global using Microsoft.AspNetCore.Components.Web;
global using Microsoft.AspNetCore.Components.WebAssembly.Hosting;