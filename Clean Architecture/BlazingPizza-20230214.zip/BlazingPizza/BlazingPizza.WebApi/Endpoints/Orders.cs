﻿using BlazingPizza.BusinessObjects.Interfaces.GetOrders;

namespace BlazingPizza.WebApi.Endpoints;

public static class Orders
{
    public static WebApplication UseOrdersEndpoints(
        this WebApplication app)
    {
        app.MapPost("/placeorder",
            async (IPlaceOrderController controller,
                PlaceOrderOrderDto order) =>
            {
                var OrderId = await controller.PlaceOrderAsync(order);
                return Results.Ok(OrderId);
            });

        app.MapGet("/getorders",
            async (IGetOrdersController controller) =>
            {
                return Results.Ok(await controller.GetOrdersAsync());
            });

        return app;
    }
}
