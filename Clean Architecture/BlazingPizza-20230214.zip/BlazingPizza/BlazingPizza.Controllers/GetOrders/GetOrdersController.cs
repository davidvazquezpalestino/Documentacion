﻿namespace BlazingPizza.Controllers.GetOrders;
public class GetOrdersController : IGetOrdersController
{
    readonly IGetOrdersInputPort InputPort;

    public GetOrdersController(IGetOrdersInputPort inputPort)
    {
        InputPort = inputPort;
    }

    public async Task<IReadOnlyCollection<OrderWithStatusDto>> GetOrdersAsync()
    {
        return await InputPort.GetOrdersAsync();
    }
}
