﻿global using BlazingPizza.BusinessObjects.Entities;
global using BlazingPizza.BusinessObjects.Interfaces.GetSpecials;

global using BlazingPizza.Presenters.GetSpecials;
global using Microsoft.Extensions.DependencyInjection;