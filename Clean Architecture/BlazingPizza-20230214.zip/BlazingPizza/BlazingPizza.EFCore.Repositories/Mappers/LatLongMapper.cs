﻿namespace BlazingPizza.EFCore.Repositories.Mappers;
internal static class LatLongMapper
{
    internal static EFEntities.LatLong ToEFLatLong(
        this BusinessObjects.ValueObjects.LatLong latLong) =>
        new EFEntities.LatLong
        {
            Latitude = latLong.Latitude,
            Longitude = latLong.Longitude
        };

    internal static BusinessObjects.ValueObjects.LatLong ToLatLong(
        this EFEntities.LatLong latLong) =>
        new BusinessObjects.ValueObjects.LatLong
        {
            Latitude = latLong.Latitude,
            Longitude = latLong.Longitude
        };
}
