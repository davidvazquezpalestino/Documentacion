﻿namespace BlazingPizza.EFCore.Repositories.Mappers;
internal static class ToppingMapper
{
    internal static BusinessObjects.Entities.Topping ToTopping(
    this Repositories.Entities.Topping topping) =>
    new BusinessObjects.Entities.Topping
    {
        Id = topping.Id,
        Name = topping.Name,
        Price = topping.Price
    };
}
