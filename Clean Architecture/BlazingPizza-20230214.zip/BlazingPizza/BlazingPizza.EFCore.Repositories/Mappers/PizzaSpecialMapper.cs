﻿namespace BlazingPizza.EFCore.Repositories.Mappers;
internal static class PizzaSpecialMapper
{
    internal static BusinessObjects.Entities.PizzaSpecial ToPizzaSpecial(
    this Repositories.Entities.PizzaSpecial pizzaSpecial) =>
    new BusinessObjects.Entities.PizzaSpecial
    {
        Id = pizzaSpecial.Id,
        Name = pizzaSpecial.Name,
        BasePrice = pizzaSpecial.BasePrice,
        Description = pizzaSpecial.Description,
        ImageUrl = pizzaSpecial.ImageUrl
    };
}
