﻿namespace BlazingPizza.EFCore.Repositories.Entities;
public class LatLong
{
    public double Latitude { get; set; }
    public double Longitude { get; set; }
}
