﻿namespace BlazingPizza.ViewModels;
public class MyOrdersViewModel : IMyOrdersViewModel
{
    readonly IMyOrdersModel Model;

    public MyOrdersViewModel(IMyOrdersModel model)
    {
        Model = model;
    }

    public IReadOnlyCollection<OrderWithStatusDto> OrdersWithStatus
    { get; private set; }

    public async Task GetOrdersAsync()
    {
        OrdersWithStatus = await Model.GetOrdersAsync();
    }
}
