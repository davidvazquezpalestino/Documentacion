﻿namespace BlazingPizza.Razor.Views.Components;
public partial class OrderReview
{
    [Parameter]
    public Order Order { get; set; }

}
