﻿namespace BlazingPizza.Razor.Views.Components;
public partial class ConfiguredPizzas
{
    [Parameter]
    public Order Order { get; set; }
}
