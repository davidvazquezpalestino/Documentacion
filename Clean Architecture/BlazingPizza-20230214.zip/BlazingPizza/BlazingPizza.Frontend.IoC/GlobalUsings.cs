﻿global using BlazingPizza.Models;
global using BlazingPizza.ViewModels;
global using Microsoft.Extensions.DependencyInjection;
global using BlazingPizza.BusinessObjects.ValueObjects;
global using BlazingPizza.Gateways;