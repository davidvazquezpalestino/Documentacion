﻿global using BlazingPizza.Controllers;
global using BlazingPizza.EFCore.Repositories;
global using BlazingPizza.UseCases;
global using Microsoft.Extensions.DependencyInjection;
global using BlazingPizza.Presenters;