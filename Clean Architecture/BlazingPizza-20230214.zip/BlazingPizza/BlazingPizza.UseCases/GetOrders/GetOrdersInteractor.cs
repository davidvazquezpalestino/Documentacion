﻿namespace BlazingPizza.UseCases.GetOrders;
public class GetOrdersInteractor : IGetOrdersInputPort
{
    readonly IBlazingPizzaQueriesRepository Repository;

    public GetOrdersInteractor(IBlazingPizzaQueriesRepository repository)
    {
        Repository = repository;
    }

    public async Task<IReadOnlyCollection<OrderWithStatusDto>> GetOrdersAsync()
    {
        return await Repository.GetOrdersAsync();
    }
}
