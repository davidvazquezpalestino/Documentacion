﻿global using BlazingPizza.BusinessObjects.Entities;
global using BlazingPizza.BusinessObjects.Interfaces.Common;
global using BlazingPizza.BusinessObjects.ValueObjects;
global using System.Net.Http.Json;
global using Microsoft.Extensions.DependencyInjection;

global using BlazingPizza.BusinessObjects.Aggregates;
global using BlazingPizza.BusinessObjects.Dtos;
