﻿namespace BlazingPizza.MAUIClient;

public partial class MainPage : ContentPage
{
    public MainPage()
    {
        InitializeComponent();
    }
}
