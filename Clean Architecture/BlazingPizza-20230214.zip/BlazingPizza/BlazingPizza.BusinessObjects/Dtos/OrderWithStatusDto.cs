﻿namespace BlazingPizza.BusinessObjects.Dtos;
public class OrderWithStatusDto : BaseOrder
{
    const string Preparing = "Preparando";
    const string OutForDelivery = "En camino";
    const string Delivered = "Entregado";

    public readonly static TimeSpan PreparationDurationTime =
        TimeSpan.FromSeconds(10);

    public readonly static TimeSpan DeliveryDurationTime =
        TimeSpan.FromMinutes(1);

    public int PizzasCount { get; set; }
    public decimal TotalPrice { get; set; }
    public string GetFormattedTotalPrice() => TotalPrice.ToString("$ #,###.##");

    public OrderWithStatusDto(Order order)
    {
        Id = order.Id;
        CreatedTime = order.CreatedTime;
        UserId = order.UserId;
        PizzasCount = order.Pizzas.Count;
        TotalPrice = order.GetTotalPrice();
    }

    string StatusTextField;
    public string StatusText
    {
        get
        {
            var DispatchTime = CreatedTime.Add(PreparationDurationTime);

            if (DateTime.Now < DispatchTime)
            {
                StatusTextField = Preparing;
            }
            else if (DateTime.Now < DispatchTime + DeliveryDurationTime)
            {
                StatusTextField = OutForDelivery;
            }
            else
            {
                StatusTextField = Delivered;
            }
            return StatusTextField;
        }
    }
    public bool IsDelivery => StatusTextField == Delivered;
}
