﻿namespace BlazingPizza.BusinessObjects.Enums;
public enum PizzaSize
{
    Default = 30,
    Minimum = 20,
    Maximum = 40,
    Increment = 2
}
