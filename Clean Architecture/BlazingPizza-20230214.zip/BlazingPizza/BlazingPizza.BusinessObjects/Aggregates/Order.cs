﻿using BlazingPizza.BusinessObjects.Dtos;

namespace BlazingPizza.BusinessObjects.Aggregates;
public class Order : BaseOrder
{
    public Order()
    {
        PizzasField = new();
    }

    public Order(int orderId, DateTime createdTime, string userId) : this()
    {
        Id= orderId;
        CreatedTime= createdTime;
        UserId= userId;
    }

    readonly List<Pizza> PizzasField;

    public Address DeliveryAddress { get; private set; } =
        new Address("", "", "", "", "", "");
    public LatLong DeliveryLocation { get; private set; } = new();
    public IReadOnlyCollection<Pizza> Pizzas =>
        PizzasField;

    public void AddPizza(Pizza pizza) =>
        PizzasField.Add(pizza);

    public Order AddPizzas(IEnumerable<Pizza> pizzas)
    {
        if (pizzas != null)
        {
            PizzasField.AddRange(pizzas);
        }
        return this;
    }

    public void RemovePizza(Pizza pizza) =>
        PizzasField.Remove(pizza);

    public Order SetDeliveryAddress(Address deliveryAddress)
    {
        DeliveryAddress = deliveryAddress;
        return this;
    }

    public Order SetDeliveryLocation(LatLong deliveryLocation)
    {
        DeliveryLocation = deliveryLocation;
        return this;
    }

    public decimal GetTotalPrice() =>
        PizzasField.Sum(p => p.GetTotalPrice());

    public string GetFormattedTotalPrice() =>
        GetTotalPrice().ToString("$ #.##");

    public bool HasPizzas => Pizzas.Any();

    public static explicit operator PlaceOrderOrderDto(Order order) =>
        new PlaceOrderOrderDto
        {
            UserId= order.UserId,
            DeliveryAddress= order.DeliveryAddress,
            DeliveryLocation= order.DeliveryLocation,
            Pizzas = order.Pizzas.Select(p => (PlaceOrderPizzaDto) p).ToList()
        };
}
