﻿namespace BlazingPizza.BusinessObjects.Interfaces.GetOrders;
public interface IGetOrdersController
{
    Task<IReadOnlyCollection<OrderWithStatusDto>> GetOrdersAsync();
}
