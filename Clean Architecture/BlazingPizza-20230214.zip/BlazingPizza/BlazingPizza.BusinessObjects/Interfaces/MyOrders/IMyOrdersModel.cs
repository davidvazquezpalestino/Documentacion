﻿namespace BlazingPizza.BusinessObjects.Interfaces.MyOrders;
public interface IMyOrdersModel
{
    Task<IReadOnlyCollection<OrderWithStatusDto>> GetOrdersAsync();
}
