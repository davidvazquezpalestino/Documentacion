﻿namespace BlazingPizza.BusinessObjects.Interfaces.MyOrders;
public interface IMyOrdersViewModel
{
    IReadOnlyCollection<OrderWithStatusDto> OrdersWithStatus { get; }
    Task GetOrdersAsync();
}
